

/**
 * Pracownik.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class Pracownik {

	private int id;
	private String imie;
	private String nazwisko;
	private List<Zadanie> zadania;
	public Maszyna m_Maszyna;
	public Suplement m_Suplement;

	public Pracownik(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param maszyna
	 * @param status
	 */
	public void aktualizacjaStatusuMaszyny(Maszyna maszyna, String status){

	}

	/**
	 * 
	 * @param maszyna
	 */
	public void dodanieMaszyny(Maszyna maszyna){

	}

	/**
	 * 
	 * @param pracownik
	 */
	public List<Zadanie> monitorowanieZadan(Pracownik pracownik){
		return null;
	}

	/**
	 * 
	 * @param pracownik
	 * @param zadanie
	 */
	public void nadawanieZadan(Pracownik pracownik, Zadanie zadanie){

	}

	/**
	 * 
	 * @param kryterium
	 */
	public List<Maszyna> serowanieMaszyn(int kryterium){
		return null;
	}

	/**
	 * 
	 * @param karnet
	 */
	public void tworzenieKarnetow(Karnet karnet){

	}

	/**
	 * 
	 * @param oferta
	 */
	public void tworzenieOfertPromocyjnych(Oferta oferta){

	}

	/**
	 * 
	 * @param wydarzenie
	 */
	public void tworzenieWydarzen(Wydarzenie wydarzenie){

	}

	/**
	 * 
	 * @param suplement
	 * @param ilosc
	 */
	public void zamawianieSuplementow(Suplement suplement, int ilosc){

	}

	public void zbieranieStatystyk(){

	}
}//end Pracownik