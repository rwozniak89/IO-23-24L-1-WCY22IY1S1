

/**
 * Uzytkownik.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class Uzytkownik {

	private String avatar;
	private String email;
	private String haslo;
	private List<Trening> historiaTreningow;
	private int id;
	private int punkty;
	public Maszyna m_Maszyna;
	public Suplement m_Suplement;

	public Uzytkownik(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param druzyna
	 */
	public void dolaczenieDoDruzyny(Druzyna druzyna){

	}

	/**
	 * 
	 * @param kod
	 */
	public void jedzeniePosilkow(String kod){

	}

	public float kalkulatorZapotrzebowaniaKalorycznego(){
		return null;
	}

	public float obliczanieBMR(){
		return null;
	}

	/**
	 * 
	 * @param avatar
	 */
	public void personalizacja(String avatar){

	}

	public void planowanieTreningow(){

	}

	/**
	 * 
	 * @param kcal
	 */
	public float podliczenieKalorii(float kcal){
		return null;
	}

	/**
	 * 
	 * @param cel
	 */
	public List<Trening> propozycjeTreningow(Cel cel){
		return null;
	}

	public List<Trening> przegladanieHistoriiTreningow(){
		return null;
	}

	/**
	 * 
	 * @param email
	 * @param haslo
	 */
	public void rejestracja(String email, String haslo){

	}

	/**
	 * 
	 * @param kod
	 */
	public Film skanowanieKodow(String kod){
		return null;
	}

	public List<Trening> udostepnianiePlanow(){
		return null;
	}

	/**
	 * 
	 * @param suplement
	 * @param ilosc
	 */
	public void umowienieSuplementow(Suplement suplement, int ilosc){

	}

	/**
	 * 
	 * @param trener
	 * @param termin
	 */
	public void umowienieTreninguZTrenerem(Pracownik trener, Date termin){

	}

	/**
	 * 
	 * @param cel
	 */
	public void ustawianieCelu(Cel cel){

	}

	/**
	 * 
	 * @param karnet
	 */
	public Karnet wyborKarnetu(Karnet karnet){
		return null;
	}

	/**
	 * 
	 * @param email
	 */
	public void zaproszenieZnajomego(String email){

	}
}//end Uzytkownik