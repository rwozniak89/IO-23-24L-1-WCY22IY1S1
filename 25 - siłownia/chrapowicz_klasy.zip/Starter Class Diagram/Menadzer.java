

/**
 * Menadzer.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class Menadzer {

	private int id;
	private String imie;
	private String nazwisko;
	private List<Zadanie> zadania;
	public Pracownik m_Pracownik;

	public Menadzer(){

	}

	public void finalize() throws Throwable {

	}
	public List<Wskaznik> analizaWskaznikow(){
		return null;
	}

	public List<Statystyki> przegladStatystykPracownikow(){
		return null;
	}

	public List<Raport> tworzenieRaportow(){
		return null;
	}

	/**
	 * 
	 * @param pracownik
	 */
	public void zarzadzaniePracownikami(Pracownik pracownik){

	}
}//end Menadzer