

/**
 * Maszyna.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class Maszyna {

	private int id;
	private String nazwa;
	private String status;

	public Maszyna(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param status
	 */
	public void aktualizacjaStatusu(String status){

	}

	public void pokazStatus(){

	}

	/**
	 * 
	 * @param uzytkownik
	 * @param czas
	 */
	public void rejestracjaUzytkownika(Uzytkownik uzytkownik, Date czas){

	}

	public Film wyswietlanieInstruktaży(){
		return null;
	}

	/**
	 * 
	 * @param status
	 */
	public void zmianaStatusu(String status){

	}
}//end Maszyna