

/**
 * Suplement.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class Suplement {

	private int id;
	private String nazwa;
	private String status;

	public Suplement(){

	}

	public void finalize() throws Throwable {

	}
	public void pokazStatus(){

	}
}//end Suplement