

/**
 * SystemAplikacji.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class SystemAplikacji {

	private String bazaDanych;
	private String serwer;
	private String wersja;
	public Pracownik m_Pracownik;
	public Menadzer m_Menadzer;
	public Uzytkownik m_Uzytkownik;

	public SystemAplikacji(){

	}

	public void finalize() throws Throwable {

	}
	public List<Wskaznik> analizaDanych(){
		return null;
	}

	public void backupDanych(){

	}

	public List<Raport> generowanieRaportow(){
		return null;
	}

	public void monitorowanieSystemu(){

	}

	/**
	 * 
	 * @param uzytkownik
	 * @param kwota
	 */
	public void przetwarzaniePlatnosci(Uzytkownik uzytkownik, float kwota){

	}

	public void synchronizacjaDanych(){

	}

	public void zbieranieDanych(){

	}
}//end SystemAplikacji