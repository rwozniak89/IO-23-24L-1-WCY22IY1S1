

/**
 * Trening.java
 * @author Gekko
 * @version 1.0
 * @updated 28-May-2024 22:02:49
 */
public class Trening {

	private List<Cwiczenie> cwiczenia;
	private int czasTrwania;
	private Date data;
	private int id;

	public Trening(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param cwiczenie
	 */
	public void dodajCwiczenie(Cwiczenie cwiczenie){

	}

	public int obliczIloscCwiczen(){
		return 0;
	}

	public Statystyki pokazStatystyki(){
		return null;
	}

	public void rozpoczynanie(){

	}

	public void zakonczenie(){

	}

	public void zapisPostepow(){

	}
}//end Trening