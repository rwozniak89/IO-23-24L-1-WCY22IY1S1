

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:36
 */
public class CzatGrupowy {

	private int id;
	private String nazwa;
	private List<Uzytkownik> uczestnicy;
	private List<Wiadomosc> wiadomosci;
	public Wiadomosc m_Wiadomosc;

	public CzatGrupowy(){

	}

	public void finalize() throws Throwable {

	}
	public void dodajUczestnika(uzytkownik: U�ytkownik)(){

	}

	public void przegladWiadomosci()(){

	}

	public void usunUczestnika(uzytkownik: U�ytkownik)(){

	}

	public List<Wiadomosc> wyslijWiadomosc(uzytkownik: U�ytkownik, tresc: String)(){
		return null;
	}
}//end CzatGrupowy