

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:45
 */
public class Zgloszenie {

	private int id;
	private String status;
	private String tresc;
	private int uzytkownikId;

	public Zgloszenie(){

	}

	public void finalize() throws Throwable {

	}
	public void aktualizujStatus(status: String)(){

	}

	public void wyslijZgloszenie(uzytkownikId: int, tresc: String)(){

	}
}//end Zgloszenie