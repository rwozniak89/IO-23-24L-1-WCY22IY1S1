

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:42
 */
public class Serial {

	private String gatunek;
	private int id;
	private int liczbaOdcinkow;
	private String opis;
	private String rezyseria;
	private String tytul;
	public Ocena m_Ocena;

	public Serial(){

	}

	public void finalize() throws Throwable {

	}
	public void ocen(ocena: int)(){

	}

	public void odtworzOdcinek(odcinekId: int)(){

	}

	public void zatrzymaj()(){

	}
}//end Serial