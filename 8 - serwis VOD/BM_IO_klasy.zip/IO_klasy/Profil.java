

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:41
 */
public class Profil {

	private Film[] HistoriaObejrzanychFilmow;
	private Film[] listaDoObejrzenia;
	private String Nazwa;
	private boolean ustawieniaDziecka;
	private int Wiek;
	public Film m_Film;
	public Serial m_Serial;
	public Odtwarzacz m_Odtwarzacz;

	public Profil(){

	}

	public void finalize() throws Throwable {

	}
	public void dodajDoHistorii(Film)(){

	}

	public void dodajDoListy(Film)(){

	}

	public void kontynuujOgladanie(Film)(){

	}

	public void usunZHistorii(Film)(){

	}

	public void usunZListy(Film)(){

	}

	public Film[] wyswietlPolecane()(){
		return null;
	}
}//end Profil