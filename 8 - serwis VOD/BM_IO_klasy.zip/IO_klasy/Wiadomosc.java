

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:44
 */
public class Wiadomosc {

	private Date dataWyslania;
	private int id;
	private Uzytkownik nadawca;
	private String tresc;

	public Wiadomosc(){

	}

	public void finalize() throws Throwable {

	}
	public void edytujWiadomosc(tresc: String)(){

	}

	public void usunWiadomosc()(){

	}
}//end Wiadomosc