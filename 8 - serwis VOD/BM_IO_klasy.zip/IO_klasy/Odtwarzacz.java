

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:39
 */
public class Odtwarzacz {

	private int czasOdtworzony;
	private String czat;
	private boolean czyOdtwarzane;
	private boolean czyWspolneOgladanie;
	private Produkcja[] odtwarzanaProdukcja;
	private boolean pelnyEkran;
	private int poziomDzwieku;
	public CzatGrupowy m_CzatGrupowy;

	public Odtwarzacz(){

	}

	public void finalize() throws Throwable {

	}
	public void odtworzNastepny(Produkcja)(){

	}

	public void odtworzZdalnie()(){

	}

	public void pauza()(){

	}

	public void pominWstep()(){

	}

	public void przesun(int)(){

	}

	public void wyswietlCzat()(){

	}

	public Produkcja[] wyswietlPolecane()(){
		return null;
	}

	public void zamknijOdtwarzacz()(){

	}

	public void zmianaDzwieku(int)(){

	}

	public void zmienPelnyEkran()(){

	}
}//end Odtwarzacz