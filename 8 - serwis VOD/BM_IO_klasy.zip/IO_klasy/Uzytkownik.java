

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:43
 */
public class Uzytkownik {

	private String email;
	private String haslo;
	private int id;
	private String imie;
	private String nazwisko;
	private String plan_subskrypcji;
	public Profil m_Profil;
	public Zgloszenie m_Zgloszenie;

	public Uzytkownik(){

	}

	public void finalize() throws Throwable {

	}
	public void kontynuujOgladanie(produkcjaId: int)(){

	}

	public List<Film> przegladajFilmy()(){
		return null;
	}

	public List<Seriale> przegladajSeriale()(){
		return null;
	}

	public void usunZHistorii(produkcjaId: int)(){

	}

	public Profil[] utworzProfil(nazwa: String, ograniczenia: String)(){
		return null;
	}

	public void wyloguj()(){

	}

	public List<Produkcja> wyszukajProdukcje(kryteria: Map<String, String>)(){
		return null;
	}

	public boolean zaloguj(email: String, haslo: String)(){
		return false;
	}
}//end Uzytkownik