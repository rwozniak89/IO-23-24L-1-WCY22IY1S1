

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:40
 */
public class Powiadomienie {

	private Date dataWyslania;
	private int id;
	private string tresc;

	public Powiadomienie(){

	}

	public void finalize() throws Throwable {

	}
	public void wyslijPowiadomienie(tresc: String, dataWyslania: Date)(){

	}
}//end Powiadomienie