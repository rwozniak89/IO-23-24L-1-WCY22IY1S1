

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:38
 */
public class Ocena {

	private int id_produkcji;
	private int id_uzytkownika;
	private int ocena;

	public Ocena(){

	}

	public void finalize() throws Throwable {

	}
	public void edytuj_ocen�(nowa_ocena)(){

	}

	public void oblicz_�redni�_ocen�(oceny)(){

	}

	public void usu�_ocen�()(){

	}
}//end Ocena