

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:34
 */
public class Administrator {

	private String email;
	private String haslo;
	private int id;
	private String imie;
	private String nazwisko;
	public Film m_Film;
	public Serial m_Serial;
	public Powiadomienie m_Powiadomienie;
	public Zgloszenie m_Zgloszenie;

	public Administrator(){

	}

	public void finalize() throws Throwable {

	}
	public void dodajProdukcje(produkcja: Produkcja)(){

	}

	public void odpowiadajNaZgloszenia(){

	}

	public Map<String, Object> przegladajStatystyki()(){
		return null;
	}

	public void usunProdukcje(produkcjaId: int)(){

	}

	public void wyslijPowiadomienie(powiadomienie: Powiadomienie)(){

	}
}//end Administrator