

/**
 * @author Bartek
 * @version 1.0
 * @created 20-maj-2024 17:06:37
 */
public class Film {

	private int dlugosc;
	private String gatunek;
	private int id;
	private String opis;
	private String rezyseria;
	private String tytul;
	public Ocena m_Ocena;

	public Film(){

	}

	public void finalize() throws Throwable {

	}
	public void ocenOcena(int)(){

	}

	public void odtworz()(){

	}

	public void zatrzymaj()(){

	}
}//end Film